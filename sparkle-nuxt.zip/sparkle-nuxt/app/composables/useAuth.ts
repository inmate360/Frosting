export const useAuth = () => {
  const user = useState<{ email: string; coins: number } | null>('user', () => null)
  const refresh = async () => {
    const r: any = await useRequestFetch()('/api/auth/me').catch(() => null)
    user.value = r?.user ?? null
  }
  const logout = async () => {
    await $fetch('/api/auth/logout', { method: 'POST' })
    user.value = null
    await navigateTo('/')
  }
  return { user, refresh, logout }
}
