<script setup lang="ts">
const { refresh } = useAuth()
await useAsyncData('me', async () => { await refresh(); return true })
</script>

<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>
