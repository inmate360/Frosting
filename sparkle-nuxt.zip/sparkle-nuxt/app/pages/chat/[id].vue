<script setup lang="ts">
import { avatarBg, profiles, type Msg } from '#shared/utils/profiles'
definePageMeta({ middleware: () => { if (!useAuth().user.value) return navigateTo('/login') } })

const id = useRoute().params.id as string
const p = profiles.find(x => x.id === id)
if (!p) throw createError({ statusCode: 404, statusMessage: 'Profile not found', fatal: true })

const { user } = useAuth()
const { data: msgs } = await useFetch<Msg[]>(`/api/chat/${id}`, { headers: useRequestHeaders(['cookie']), default: () => [] })
const text = ref('')
const busy = ref(false)
const err = ref('')
const box = ref<HTMLElement>()

watch(() => msgs.value?.length, async () => {
  await nextTick()
  if (box.value) box.value.scrollTop = box.value.scrollHeight
}, { flush: 'post' })

async function send() {
  const t = text.value.trim()
  if (!t || busy.value) return
  busy.value = true
  err.value = ''
  text.value = ''
  msgs.value!.push({ role: 'user', text: t })
  try {
    const r = await $fetch<{ reply: string; coins: number }>(`/api/chat/${id}`, { method: 'POST', body: { text: t } })
    msgs.value!.push({ role: 'assistant', text: r.reply })
    user.value!.coins = r.coins
  } catch (e: any) {
    msgs.value!.pop()
    text.value = t
    err.value = e?.data?.statusMessage || 'Could not send. Try again.'
  }
  busy.value = false
}

async function topup() {
  const r = await $fetch<{ coins: number }>('/api/wallet/topup', { method: 'POST' })
  user.value!.coins = r.coins
  err.value = ''
}
</script>

<template>
  <div class="wrap chat">
    <div class="chathead">
      <NuxtLink :to="`/profiles/${p.id}`" class="mini" :style="{ background: avatarBg(p) }">{{ p.name[0] }}</NuxtLink>
      <div><b>{{ p.name }}</b> <small class="mut">AI character. 1 coin per message.</small></div>
    </div>
    <div ref="box" class="msgs">
      <p v-if="!msgs?.length" class="mut">Say hello to {{ p.name }}. Your first message costs 1 coin.</p>
      <div v-for="(m, i) in msgs" :key="i" class="msg" :class="m.role">{{ m.text }}</div>
      <div v-if="busy" class="msg assistant mut">{{ p.name }} is typing…</div>
    </div>
    <p v-if="err" class="err">
      {{ err }}
      <button v-if="(user?.coins ?? 0) < 1" class="btn" @click="topup">Add 20 demo coins</button>
    </p>
    <form class="compose" @submit.prevent="send">
      <input v-model="text" placeholder="Write a message" maxlength="500" />
      <button class="btn" :disabled="busy || !text.trim()">Send</button>
    </form>
  </div>
</template>
