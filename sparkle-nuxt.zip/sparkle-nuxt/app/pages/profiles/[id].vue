<script setup lang="ts">
import { avatarBg, profiles } from '#shared/utils/profiles'
const p = profiles.find(x => x.id === useRoute().params.id)
if (!p) throw createError({ statusCode: 404, statusMessage: 'Profile not found', fatal: true })
const { user } = useAuth()
useHead({ title: `${p.name} — ${useRuntimeConfig().public.appName}` })
</script>

<template>
  <div class="wrap split">
    <div class="portrait" :style="{ background: avatarBg(p) }"><span class="init">{{ p.name[0] }}</span></div>
    <div>
      <h1>{{ p.name }}, {{ p.age }}</h1>
      <p class="mut">{{ p.city }}. {{ p.vibe }}</p>
      <p>{{ p.bio }}</p>
      <div class="row wrapx"><span v-for="i in p.interests" :key="i" class="pill">{{ i }}</span></div>
      <p class="mut small">{{ p.name }} is a fictional AI character. Each message costs 1 coin.</p>
      <NuxtLink class="btn" :to="user ? `/chat/${p.id}` : '/signup'">{{ user ? `Chat with ${p.name}` : 'Join to start chatting' }}</NuxtLink>
    </div>
  </div>
</template>
