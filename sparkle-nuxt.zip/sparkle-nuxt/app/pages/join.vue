<script setup lang="ts">
import { profiles } from '#shared/utils/profiles'
const filter = ref<'all' | 'f' | 'm'>('all')
const tabs = [['all', 'Everyone'], ['f', 'Women'], ['m', 'Men']] as const
const list = computed(() => profiles.filter(p => filter.value === 'all' || p.gender === filter.value))
</script>

<template>
  <div class="wrap">
    <h1>Browse profiles</h1>
    <p class="mut">Every profile is a fictional AI character. Choose who you want to meet.</p>
    <div class="row tabs">
      <button v-for="[k, label] in tabs" :key="k" class="btn" :class="{ ghost: filter !== k }" @click="filter = k">{{ label }}</button>
    </div>
    <div class="tiles"><ProfileCard v-for="p in list" :key="p.id" :p="p" /></div>
  </div>
</template>
