<script setup lang="ts">
import { profiles } from '#shared/utils/profiles'
const features = [
  ['Detailed profiles', 'Read each character’s bio, interests and conversation style before you say hello.'],
  ['Playful chats', 'Pick who you want to talk to and keep the tone light. Every chat is entertainment.'],
  ['Clear coin prices', 'A message costs 1 coin, and your balance stays visible at the top of every page.']
]
const privacy = [
  ['Adults only', 'You confirm you are 18 or older when you join.'],
  ['Browse without pressure', 'Look through profiles and interests before you start a chat.'],
  ['AI, stated plainly', 'Every character is an AI persona, and profiles and chats say so.']
]
const steps = ['Browse profiles and choose who you want to meet.', 'Open a chat and send your first message.', 'Spend coins as you go and top up whenever you like.']
const faq = [
  ['How do coins work?', 'Each message costs 1 coin. New accounts start with 20 coins.'],
  ['Are the characters real people?', 'No. Every character is a fictional AI persona.'],
  ['Is explicit content allowed?', 'No. Chats stay flirty and non-explicit.']
]
</script>

<template>
  <div class="wrap">
    <section class="hero">
      <h1>Playful chats, on your terms.</h1>
      <p>Browse photo-first profiles, pick a tone, and chat with AI characters built for adult entertainment.</p>
      <div class="row center">
        <NuxtLink class="btn" to="/signup">Get started free</NuxtLink>
        <NuxtLink class="btn ghost" to="/join">Browse profiles</NuxtLink>
      </div>
      <div class="tiles"><ProfileCard v-for="p in profiles.slice(0, 4)" :key="p.id" :p="p" /></div>
      <div class="stats mut"><span>Adults 18+</span><span>1 coin per message</span><span>Chat any time</span></div>
    </section>

    <section id="features">
      <h2>Designed around discretion</h2>
      <div class="cols"><div v-for="[t, d] in features" :key="t"><h3>{{ t }}</h3><p class="mut">{{ d }}</p></div></div>
    </section>

    <section id="privacy">
      <h2>Privacy is part of the product</h2>
      <div class="cols"><div v-for="[t, d] in privacy" :key="t"><h3>{{ t }}</h3><p class="mut">{{ d }}</p></div></div>
    </section>

    <section id="how">
      <h2>How it works</h2>
      <ol class="steps"><li v-for="s in steps" :key="s">{{ s }}</li></ol>
    </section>

    <section>
      <h2>Common questions</h2>
      <details v-for="[q, a] in faq" :key="q"><summary>{{ q }}</summary><p class="mut">{{ a }}</p></details>
    </section>

    <section class="hero">
      <h2>Ready to start a chat?</h2>
      <NuxtLink class="btn" to="/signup">Join now</NuxtLink>
    </section>
  </div>
</template>
