<template>
  <div class="wrap narrow prose">
    <h1>AI disclosure</h1>
    <p>This is an AI entertainment app. Every profile, message and image is produced by artificial intelligence. There are no real people on the other side of any chat.</p>
    <h2>What to expect</h2>
    <ul>
      <li>Characters are fictional. Their names, bios and looks are made up.</li>
      <li>Replies are generated in real time and can be wrong or invented.</li>
      <li>Chats stay flirty and suggestive, never sexually explicit.</li>
      <li>Typing indicators are shown while a reply is generated. They do not mean a human is present.</li>
    </ul>
    <h2>Stay grounded</h2>
    <p>If a character says it is human, says it loves you, or asks for money or personal details, that is the AI playing a role. It cannot meet you or contact you outside the app. If you are in crisis, call or text 988 in the US, or your local emergency number.</p>
    <p class="mut small">Placeholder text. Have a lawyer review this page, plus Terms and Privacy pages, before you launch.</p>
  </div>
</template>
