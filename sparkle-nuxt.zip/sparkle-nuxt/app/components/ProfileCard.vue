<script setup lang="ts">
import { avatarBg, type Profile } from '#shared/utils/profiles'
defineProps<{ p: Profile }>()
</script>

<template>
  <NuxtLink :to="`/profiles/${p.id}`" class="tile" :style="{ background: avatarBg(p) }">
    <span class="init">{{ p.name[0] }}</span>
    <span class="cap">
      <b>{{ p.name }}, {{ p.age }}</b>
      <small>{{ p.city }}. {{ p.vibe }}</small>
    </span>
    <span class="ai">AI character</span>
  </NuxtLink>
</template>
