<script setup lang="ts">
const props = defineProps<{ mode: 'login' | 'signup' }>()
const { refresh } = useAuth()
const email = ref('')
const password = ref('')
const adult = ref(false)
const err = ref('')
const busy = ref(false)

async function submit() {
  err.value = ''
  busy.value = true
  try {
    await $fetch(`/api/auth/${props.mode}`, { method: 'POST', body: { email: email.value, password: password.value, adult: adult.value } })
    await refresh()
    await navigateTo('/join')
  } catch (e: any) {
    err.value = e?.data?.statusMessage || e?.data?.message || 'Something went wrong. Try again.'
  }
  busy.value = false
}
</script>

<template>
  <div class="narrow wrap">
    <h1>{{ mode === 'signup' ? 'Create your account' : 'Welcome back' }}</h1>
    <p class="mut">{{ mode === 'signup' ? 'You start with 20 free coins.' : 'Sign in to continue your chats.' }}</p>
    <div class="stack">
      <input v-model="email" type="email" placeholder="Email" autocomplete="email" />
      <input v-model="password" type="password" placeholder="Password (8+ characters)" :autocomplete="mode === 'signup' ? 'new-password' : 'current-password'" @keyup.enter="submit" />
      <label v-if="mode === 'signup'" class="check">
        <input v-model="adult" type="checkbox" />
        I am 18 or older and understand every character here is an AI, not a real person.
      </label>
      <p v-if="err" class="err">{{ err }}</p>
      <button class="btn" :disabled="busy" @click="submit">{{ mode === 'signup' ? 'Create account' : 'Sign in' }}</button>
      <NuxtLink class="mut" :to="mode === 'signup' ? '/login' : '/signup'">
        {{ mode === 'signup' ? 'Already a member? Sign in' : 'New here? Create an account' }}
      </NuxtLink>
    </div>
  </div>
</template>
