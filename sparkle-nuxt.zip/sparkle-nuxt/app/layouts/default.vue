<script setup lang="ts">
const { user, logout } = useAuth()
const name = useRuntimeConfig().public.appName
</script>

<template>
  <header class="bar">
    <NuxtLink to="/" class="logo">{{ name }}</NuxtLink>
    <nav>
      <NuxtLink to="/#features">Features</NuxtLink>
      <NuxtLink to="/#privacy">Privacy</NuxtLink>
      <NuxtLink to="/#how">How it works</NuxtLink>
      <NuxtLink to="/join">Browse</NuxtLink>
    </nav>
    <div class="row">
      <template v-if="user">
        <span class="pill">{{ user.coins }} coins</span>
        <button class="btn ghost" @click="logout">Sign out</button>
      </template>
      <template v-else>
        <NuxtLink class="btn ghost" to="/login">Sign in</NuxtLink>
        <NuxtLink class="btn" to="/signup">Join {{ name }}</NuxtLink>
      </template>
    </div>
  </header>
  <main><slot /></main>
  <footer class="wrap">
    <span>© {{ new Date().getFullYear() }} {{ name }}. Entertainment with AI characters, for adults 18+.</span>
    <NuxtLink to="/ai-disclosure">AI disclosure</NuxtLink>
  </footer>
</template>
