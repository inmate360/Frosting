# Sparkle clone (Nuxt 4)

AI-character entertainment chat app: landing page, 18+ sign-up, profile browsing (women/men filter), profile pages, coin-metered chat, AI disclosure page.

```bash
npm install
npm run dev        # http://localhost:3000
```

## Config (env vars)
| Var | Purpose |
| --- | --- |
| `NUXT_SESSION_SECRET` | Signs the session cookie. **Set a long random value in production.** |
| `NUXT_LLM_URL` / `NUXT_LLM_KEY` / `NUXT_LLM_MODEL` | OpenAI-compatible chat completions endpoint. Unset = canned replies. |
| `NUXT_PUBLIC_APP_NAME` | Brand name (rename before a public launch). |

## Notes
- Storage is Nitro `useStorage('data')`: files in `.data/` on a VPS, memory on Vercel (ephemeral). Use a Redis/Upstash/DB driver for production.
- `/api/wallet/topup` hands out free demo coins. Replace it with real checkout (e.g. Stripe).
- Profiles live in `shared/utils/profiles.ts` (fictional AI characters, gradient placeholders instead of photos).
- Not included yet: German/English i18n, admin panel, Terms/Privacy/Help pages, rate limiting, email verification.
- Characters stay non-explicit and are labelled as AI everywhere. Keep it that way, and have a lawyer review the legal pages.
