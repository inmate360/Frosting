// Users and chats live in Nitro storage. fs keeps data on a VPS; Vercel's disk is
// read-only, so it falls back to memory (demo only). Swap in a Redis/KV driver for production.
const persist = !process.env.VERCEL

export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  css: ['~/assets/css/main.css'],
  app: { head: { title: 'Sparkle — Private Entertainment Chats', meta: [{ name: 'description', content: 'Private entertainment chats with AI characters, for adults 18+.' }] } },
  runtimeConfig: {
    sessionSecret: 'dev-secret-change-me', // NUXT_SESSION_SECRET
    llmUrl: '', llmKey: '', llmModel: '',   // NUXT_LLM_URL / NUXT_LLM_KEY / NUXT_LLM_MODEL (OpenAI-compatible)
    public: { appName: 'Sparkle' }          // NUXT_PUBLIC_APP_NAME
  },
  nitro: { storage: { data: persist ? { driver: 'fs', base: './.data' } : { driver: 'memory' } } }
})
