import { randomUUID } from 'node:crypto'

export default defineEventHandler(async (event) => {
  const { email, password, adult } = await readBody(event)
  const e = String(email || '').trim().toLowerCase()
  if (!/^\S+@\S+\.\S+$/.test(e)) throw createError({ statusCode: 400, statusMessage: 'Enter a valid email address' })
  if (String(password || '').length < 8) throw createError({ statusCode: 400, statusMessage: 'Password must be at least 8 characters' })
  if (adult !== true) throw createError({ statusCode: 400, statusMessage: 'Confirm that you are 18 or older to join' })
  const db = useStorage('data')
  if (await db.hasItem(`email:${e}`)) throw createError({ statusCode: 409, statusMessage: 'That email is already registered' })
  const id = randomUUID()
  await db.setItem(`user:${id}`, { id, email: e, hash: hashPw(String(password)), coins: 20 })
  await db.setItem(`email:${e}`, { id })
  startSession(event, id)
  return { ok: true }
})
