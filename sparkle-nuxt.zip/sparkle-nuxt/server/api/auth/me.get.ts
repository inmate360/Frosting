export default defineEventHandler(async (event) => {
  const u = await getUser(event)
  return { user: u ? { email: u.email, coins: u.coins } : null }
})
