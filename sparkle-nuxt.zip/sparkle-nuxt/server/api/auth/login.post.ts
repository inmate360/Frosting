export default defineEventHandler(async (event) => {
  const { email, password } = await readBody(event)
  const db = useStorage('data')
  const ref = await db.getItem<{ id: string }>(`email:${String(email || '').trim().toLowerCase()}`)
  const u = ref ? await db.getItem<User>(`user:${ref.id}`) : null
  if (!u || !checkPw(String(password || ''), u.hash)) throw createError({ statusCode: 401, statusMessage: 'Wrong email or password' })
  startSession(event, u.id)
  return { ok: true }
})
