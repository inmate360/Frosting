export default defineEventHandler((event) => {
  deleteCookie(event, 'sp', { path: '/' })
  return { ok: true }
})
