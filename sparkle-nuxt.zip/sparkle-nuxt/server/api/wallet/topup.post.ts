// Demo only: grants 20 free coins. Replace with a real checkout (e.g. Stripe) before launch.
export default defineEventHandler(async (event) => {
  const u = await requireUser(event)
  u.coins += 20
  await useStorage('data').setItem(`user:${u.id}`, u)
  return { coins: u.coins }
})
