import type { Msg } from '#shared/utils/profiles'

export default defineEventHandler(async (event) => {
  const u = await requireUser(event)
  const p = requireProfile(event)
  const body = await readBody<{ text?: string }>(event)
  const text = String(body?.text || '').trim().slice(0, 500)
  if (!text) throw createError({ statusCode: 400, statusMessage: 'Write a message first' })
  if (u.coins < 1) throw createError({ statusCode: 402, statusMessage: 'You are out of coins' })

  const db = useStorage('data')
  const key = `chat:${u.id}:${p.id}`
  const msgs = (await db.getItem<Msg[]>(key)) ?? []
  msgs.push({ role: 'user', text })
  u.coins -= 1
  await db.setItem(`user:${u.id}`, u)

  let reply: string
  try {
    reply = await makeReply(p, msgs)
  } catch {
    u.coins += 1 // refund when the reply fails
    await db.setItem(`user:${u.id}`, u)
    throw createError({ statusCode: 502, statusMessage: `${p.name} could not reply. Your coin was refunded.` })
  }
  msgs.push({ role: 'assistant', text: reply })
  await db.setItem(key, msgs.slice(-100))
  return { reply, coins: u.coins }
})
