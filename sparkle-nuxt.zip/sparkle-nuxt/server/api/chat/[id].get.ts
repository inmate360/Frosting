import type { Msg } from '#shared/utils/profiles'

export default defineEventHandler(async (event) => {
  const u = await requireUser(event)
  const p = requireProfile(event)
  return (await useStorage('data').getItem<Msg[]>(`chat:${u.id}:${p.id}`)) ?? []
})
