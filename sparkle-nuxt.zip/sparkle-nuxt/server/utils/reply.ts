import type { Msg, Profile } from '#shared/utils/profiles'

const canned = [
  'Hey you. I was hoping someone interesting would show up. What are you up to tonight?',
  'Ha, that made me smile. Tell me more. What is your idea of a perfect lazy Sunday?',
  'Okay, I like your style. Give me one thing most people never guess about you.',
  'You are fun to talk to. Should we keep this going with a game of two truths and a lie?'
]

// Without NUXT_LLM_URL set, replies are canned. Point it at any OpenAI-compatible chat completions endpoint.
export async function makeReply(p: Profile, msgs: Msg[]): Promise<string> {
  const c = useRuntimeConfig()
  if (!c.llmUrl) return canned[msgs.length % canned.length]!
  const r = await $fetch<any>(c.llmUrl, {
    method: 'POST',
    headers: { Authorization: `Bearer ${c.llmKey}` },
    body: {
      model: c.llmModel,
      max_tokens: 200,
      messages: [
        { role: 'system', content: `You are ${p.name}, a fictional AI character in an adult entertainment chat app. Persona: ${p.bio} Vibe: ${p.vibe}. Be playful and flirty but never sexually explicit. Never claim to be human or to meet in person, and never ask for money or personal details. Reply in one to three short sentences.` },
        ...msgs.slice(-12).map(m => ({ role: m.role, content: m.text }))
      ]
    }
  })
  return String(r.choices?.[0]?.message?.content ?? '').trim() || canned[0]!
}
