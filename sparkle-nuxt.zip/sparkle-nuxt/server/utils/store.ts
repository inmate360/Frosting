import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'
import type { H3Event } from 'h3'
import { profiles } from '#shared/utils/profiles'

export type User = { id: string; email: string; hash: string; coins: number }

const same = (a: string, b: string) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b))
const sign = (id: string) => `${id}.${createHmac('sha256', useRuntimeConfig().sessionSecret).update(id).digest('hex')}`

export const hashPw = (pw: string) => {
  const salt = randomBytes(16).toString('hex')
  return `${salt}:${scryptSync(pw, salt, 32).toString('hex')}`
}

export const checkPw = (pw: string, stored: string) => {
  const [salt, key] = stored.split(':')
  return same(scryptSync(pw, salt!, 32).toString('hex'), key!)
}

export const startSession = (event: H3Event, id: string) =>
  setCookie(event, 'sp', sign(id), { httpOnly: true, sameSite: 'lax', secure: !import.meta.dev, maxAge: 60 * 60 * 24 * 30, path: '/' })

export async function getUser(event: H3Event) {
  const c = getCookie(event, 'sp')
  const id = c?.split('.')[0]
  if (!c || !id || !same(sign(id), c)) return null
  return useStorage('data').getItem<User>(`user:${id}`)
}

export async function requireUser(event: H3Event) {
  const u = await getUser(event)
  if (!u) throw createError({ statusCode: 401, statusMessage: 'Sign in to continue' })
  return u
}

export function requireProfile(event: H3Event) {
  const p = profiles.find(x => x.id === getRouterParam(event, 'id'))
  if (!p) throw createError({ statusCode: 404, statusMessage: 'Profile not found' })
  return p
}
